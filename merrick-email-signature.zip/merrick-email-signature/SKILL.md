---
name: merrick-email-signature
description: "Generate a Merrick Construction email signature (Outlook-ready HTML) for an employee. Use whenever someone wants to create, build, make, or update an email signature / Outlook signature for a Merrick staff member or new hire; mentions onboarding a new employee's signature; or provides a name + title (+ mobile) with intent to produce a signature block. Handles both the construction division (MERRICK / Design-Build-Home, office line 732-758-0404) and the maintenance division (MERRICK MAINTENANCE, office line 732-531-8575), selecting the correct wordmark and office phone automatically. Trigger even if the user only says something like 'make a signature for the new estimator' or 'spin up an Outlook signature for Gaspar.'"
---

# Merrick Construction — Email Signature

Builds a Merrick employee email signature as Outlook-ready HTML from three inputs:
**name, title, mobile** (plus which **division** they're in). Everything else —
office phone, address, license, wordmark, social links — is filled in automatically.

The signature keeps the M-mark logo and wordmark as hosted images and renders the
person's name/title as live HTML text, so adding a new hire is a three-field change
with no new image to create or host.

## What varies vs. what's fixed

Per employee (ask the user for these):
- **Full name**
- **Title**
- **Mobile** number — format as `(xxx) xxx-xxxx`
- **Division** — `construction` (default) or `maintenance`

Set automatically by division:
- **Office phone** — construction `(732) 758-0404`, maintenance `(732) 531-8575`
- **Wordmark** — construction = MERRICK, maintenance = MERRICK MAINTENANCE

Fixed for everyone (in `scripts/generate_signature.py` CONFIG):
- Address `524 Prospect Avenue, Little Silver, NJ 07739`
- `NJ Contractor's License# 13VH02448100`
- Website / GuildQuality / Instagram links

## How to generate

```bash
python scripts/generate_signature.py \
    --name "Gaspar Moreau" \
    --title "Project Manager" \
    --mobile "(732) 555-0123" \
    --division construction \
    --out /mnt/user-data/outputs
```

- `--division maintenance` switches the office line and wordmark.
- Add `--embed` to inline the logos as base64 — the signature then needs **no image
  hosting** and works immediately (good fallback before hosting is set up). Without
  `--embed`, the signature references the hosted URLs in CONFIG.

Output: `signature-<Name>.htm` (or `signature-<Name>-embedded.htm`).

Always confirm the four inputs with the user before generating, then present the
`.htm` file. Offer to render a preview if useful.

## Image hosting (do this once)

The hosted version references three images that live in `assets/`:
- `m-mark.png` — the square M logo (used by everyone)
- `wordmark-construction.png` — MERRICK
- `wordmark-maintenance.png` — MERRICK MAINTENANCE

Host those three at public URLs, then set `IMAGE_URLS` at the top of
`scripts/generate_signature.py`. Until that's done, use `--embed`.

## Installing the signature in Outlook (manual, per person)

Tell the recipient either:
1. Open the `.htm` in a browser → select all (Ctrl+A) → copy (Ctrl+C) →
   Outlook → *File ▸ Options ▸ Mail ▸ Signatures ▸ New* → paste; or
2. Drop the `.htm` into `%APPDATA%\Microsoft\Signatures\` (Windows), then pick it
   in the Signatures dialog.

## Notes

- Layout is table-based with inline CSS for Outlook-desktop reliability; don't
  convert it to `<div>`/flex layout.
- Name/title use Arial bold in Merrick navy `#16273F` (the exact logo font isn't
  web-safe; this is the closest reliable match).
- To change a fixed value (address, links, license, office numbers, wordmark
  display size), edit the CONFIG block in the script — not the generated files.
