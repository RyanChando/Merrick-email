# Merrick Email Signature — Reference

## Division rules

| Division      | Office phone     | Wordmark              |
|---------------|------------------|-----------------------|
| construction  | (732) 758-0404   | MERRICK               |
| maintenance   | (732) 531-8575   | MERRICK MAINTENANCE   |

Mobile number varies per person. Everything else below is identical for everyone.

## Fixed constants

- Address: `524 Prospect Avenue, Little Silver, NJ 07739`
- License: `NJ Contractor's License# 13VH02448100`
- Website: https://merrickhomes.com/
- GuildQuality: https://www.guildquality.com/pro/Merrick-Construction-Inc
- Instagram: https://www.instagram.com/merrickconstructionco/
- Brand navy: `#16273F`

> The original signatures used Outlook "SafeLinks"-wrapped URLs. Those are added
> automatically by Microsoft Defender on send — use the clean URLs above in the
> template; do not paste SafeLinks URLs.

## Image assets (in ../assets)

| File                       | Native size | Role                 | Display W×H |
|----------------------------|-------------|----------------------|-------------|
| m-mark.png                 | 804×804     | square M logo (all)  | 74×74       |
| wordmark-construction.png  | 2116×180    | MERRICK              | 215×18      |
| wordmark-maintenance.png   | 3872×732    | MERRICK MAINTENANCE  | 200×38      |

## Hosting setup (one time)

1. Upload the three files in `assets/` to a public location, e.g.
   `https://merrickhomes.com/email/m-mark.png`.
2. Open `scripts/generate_signature.py`, set the three URLs in `IMAGE_URLS`.
3. Generate without `--embed` from then on.

Before hosting is ready, generate with `--embed` (images inlined as base64). The
embedded files are larger and Outlook handles base64 inconsistently, so switch to
hosted URLs once available.

## Why not bake the name into the logo image?

The earlier signatures rendered each person's name/title *inside* a PNG header,
which meant a new graphic per employee. This skill keeps the M-mark as a shared
hosted image and the name/title as HTML text, so a new hire is just three fields.
