#!/usr/bin/env python3
"""
Merrick Construction — email signature generator.

Fills assets/signature-template.html with one employee's details and writes an
Outlook-ready .htm file (and an optional self-contained base64 version that needs
no image hosting).

Usage:
    python generate_signature.py \
        --name "Richard Jaeger" \
        --title "Estimator" \
        --mobile "(908) 309-8107" \
        --division construction \
        --out /mnt/user-data/outputs

    # divisions: construction (default) | maintenance
    # add --embed to inline the images as base64 (no hosting required)

The office phone and wordmark are chosen automatically from --division.
Edit the CONFIG block below to set the hosted image URLs once they exist.
"""

import argparse
import base64
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(HERE, "..", "assets")
TEMPLATE = os.path.join(ASSET_DIR, "signature-template.html")

# ---------------------------------------------------------------------------
# CONFIG — set these once.
# ---------------------------------------------------------------------------

# Hosted image URLs. Replace the placeholders below with the real public URLs
# after the three images are hosted. Until then, run with --embed so the images
# are inlined as base64 and the signature works with no hosting.
IMAGE_URLS = {
    "m_mark":                "https://REPLACE-ME.merrickhomes.com/email/m-mark.png",
    "wordmark_construction": "https://REPLACE-ME.merrickhomes.com/email/wordmark-construction.png",
    "wordmark_maintenance":  "https://REPLACE-ME.merrickhomes.com/email/wordmark-maintenance.png",
}

# Constants shared by every signature.
ADDRESS = "524 Prospect Avenue, Little Silver, NJ 07739"
LICENSE = "NJ Contractor\u2019s License# 13VH02448100"  # smart apostrophe
WEBSITE_URL      = "https://merrickhomes.com/"
GUILDQUALITY_URL = "https://www.guildquality.com/pro/Merrick-Construction-Inc"
INSTAGRAM_URL    = "https://www.instagram.com/merrickconstructionco/"

# Per-division settings: office line, wordmark file, wordmark display size.
# Wordmark heights derive from each PNG's native aspect ratio at the given width.
DIVISIONS = {
    "construction": {
        "office_phone": "(732) 758-0404",
        "wordmark_file": "wordmark-construction.png",   # 2116 x 180  -> ~11.76:1
        "wordmark_url_key": "wordmark_construction",
        "wordmark_w": 215,
        "wordmark_h": 18,
    },
    "maintenance": {
        "office_phone": "(732) 531-8575",
        "wordmark_file": "wordmark-maintenance.png",     # 3872 x 732  -> ~5.29:1
        "wordmark_url_key": "wordmark_maintenance",
        "wordmark_w": 200,
        "wordmark_h": 38,
    },
}


def data_uri(path):
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return "data:image/png;base64," + b64


def build(name, title, mobile, division, embed):
    if division not in DIVISIONS:
        raise SystemExit(f"Unknown division '{division}'. Use: {', '.join(DIVISIONS)}")
    d = DIVISIONS[division]

    with open(TEMPLATE, encoding="utf-8") as f:
        html = f.read()

    if embed:
        mmark_src = data_uri(os.path.join(ASSET_DIR, "m-mark.png"))
        wordmark_src = data_uri(os.path.join(ASSET_DIR, d["wordmark_file"]))
    else:
        mmark_src = IMAGE_URLS["m_mark"]
        wordmark_src = IMAGE_URLS[d["wordmark_url_key"]]
        if "REPLACE-ME" in mmark_src or "REPLACE-ME" in wordmark_src:
            print("  WARNING: image URLs are still placeholders. "
                  "Set IMAGE_URLS in this script, or re-run with --embed.")

    tokens = {
        "FULL_NAME": name,
        "TITLE": title,
        "MOBILE": mobile,
        "OFFICE_PHONE": d["office_phone"],
        "ADDRESS": ADDRESS,
        "LICENSE": LICENSE,
        "MMARK_URL": mmark_src,
        "WORDMARK_URL": wordmark_src,
        "WORDMARK_W": str(d["wordmark_w"]),
        "WORDMARK_H": str(d["wordmark_h"]),
        "WEBSITE_URL": WEBSITE_URL,
        "GUILDQUALITY_URL": GUILDQUALITY_URL,
        "INSTAGRAM_URL": INSTAGRAM_URL,
    }
    for k, v in tokens.items():
        html = html.replace("{{" + k + "}}", v)

    # Wrap as a complete document so it both opens in a browser and drops cleanly
    # into the Outlook Signatures folder.
    doc = (
        "<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        "</head><body style=\"margin:0;\">\n" + html + "\n</body></html>\n"
    )
    return doc


def slug(name):
    return re.sub(r"[^A-Za-z0-9]+", "-", name).strip("-")


def main():
    p = argparse.ArgumentParser(description="Generate a Merrick email signature.")
    p.add_argument("--name", required=True)
    p.add_argument("--title", required=True)
    p.add_argument("--mobile", required=True)
    p.add_argument("--division", default="construction",
                   choices=list(DIVISIONS.keys()))
    p.add_argument("--embed", action="store_true",
                   help="inline images as base64 (no hosting needed)")
    p.add_argument("--out", default=".", help="output directory")
    args = p.parse_args()

    doc = build(args.name, args.title, args.mobile, args.division, args.embed)
    os.makedirs(args.out, exist_ok=True)
    suffix = "-embedded" if args.embed else ""
    fname = f"signature-{slug(args.name)}{suffix}.htm"
    path = os.path.join(args.out, fname)
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)
    print(f"  Wrote {path}")


if __name__ == "__main__":
    main()
